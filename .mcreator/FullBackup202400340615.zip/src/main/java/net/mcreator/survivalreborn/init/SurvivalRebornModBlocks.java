
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.survivalreborn.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.Block;

import net.mcreator.survivalreborn.block.TinOreBlock;
import net.mcreator.survivalreborn.block.StoneRockBlocBlock;
import net.mcreator.survivalreborn.block.MetalRefiningTableBlock;
import net.mcreator.survivalreborn.block.ForgeBlock;
import net.mcreator.survivalreborn.block.FlintblockBlock;
import net.mcreator.survivalreborn.block.FiberousPlantStage3Block;
import net.mcreator.survivalreborn.block.FiberousPlantStage2Block;
import net.mcreator.survivalreborn.block.FiberousPlantStage1Block;
import net.mcreator.survivalreborn.block.FiberousPlantStage0Block;
import net.mcreator.survivalreborn.block.DeepslateRockBlocBlock;
import net.mcreator.survivalreborn.SurvivalRebornMod;

public class SurvivalRebornModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(SurvivalRebornMod.MODID);
	public static final DeferredBlock<Block> FLINTBLOCK = REGISTRY.register("flintblock", FlintblockBlock::new);
	public static final DeferredBlock<Block> STONE_ROCK_BLOC = REGISTRY.register("stone_rock_bloc", StoneRockBlocBlock::new);
	public static final DeferredBlock<Block> TIN_ORE = REGISTRY.register("tin_ore", TinOreBlock::new);
	public static final DeferredBlock<Block> DEEPSLATE_ROCK_BLOC = REGISTRY.register("deepslate_rock_bloc", DeepslateRockBlocBlock::new);
	public static final DeferredBlock<Block> FIBEROUS_PLANT_STAGE_0 = REGISTRY.register("fiberous_plant_stage_0", FiberousPlantStage0Block::new);
	public static final DeferredBlock<Block> FIBEROUS_PLANT_STAGE_1 = REGISTRY.register("fiberous_plant_stage_1", FiberousPlantStage1Block::new);
	public static final DeferredBlock<Block> FIBEROUS_PLANT_STAGE_2 = REGISTRY.register("fiberous_plant_stage_2", FiberousPlantStage2Block::new);
	public static final DeferredBlock<Block> FIBEROUS_PLANT_STAGE_3 = REGISTRY.register("fiberous_plant_stage_3", FiberousPlantStage3Block::new);
	public static final DeferredBlock<Block> FORGE = REGISTRY.register("forge", ForgeBlock::new);
	public static final DeferredBlock<Block> METAL_REFINING_TABLE = REGISTRY.register("metal_refining_table", MetalRefiningTableBlock::new);
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
