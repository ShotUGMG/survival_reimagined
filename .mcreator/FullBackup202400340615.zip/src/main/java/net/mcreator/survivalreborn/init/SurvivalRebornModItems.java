
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.survivalreborn.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.survivalreborn.item.WarpedPlankItem;
import net.mcreator.survivalreborn.item.WarpedBarkItem;
import net.mcreator.survivalreborn.item.TinNuggetItem;
import net.mcreator.survivalreborn.item.TinIngotItem;
import net.mcreator.survivalreborn.item.StoneSawItem;
import net.mcreator.survivalreborn.item.StoneRockItem;
import net.mcreator.survivalreborn.item.StoneHammerItem;
import net.mcreator.survivalreborn.item.SprucePlankItem;
import net.mcreator.survivalreborn.item.SpruceBarkItem;
import net.mcreator.survivalreborn.item.SmallCoalChunkItem;
import net.mcreator.survivalreborn.item.RoughTinItem;
import net.mcreator.survivalreborn.item.RoughIronItem;
import net.mcreator.survivalreborn.item.RoughGoldItem;
import net.mcreator.survivalreborn.item.RoughCopperItem;
import net.mcreator.survivalreborn.item.RoughBronzeItem;
import net.mcreator.survivalreborn.item.RawTinItem;
import net.mcreator.survivalreborn.item.PlantFiberItem;
import net.mcreator.survivalreborn.item.OakPlankItem;
import net.mcreator.survivalreborn.item.OakBarkItem;
import net.mcreator.survivalreborn.item.MangrovePlankItem;
import net.mcreator.survivalreborn.item.MangroveBarkItem;
import net.mcreator.survivalreborn.item.LargeWarpedBarkItem;
import net.mcreator.survivalreborn.item.LargeSpruceBarkItem;
import net.mcreator.survivalreborn.item.LargeOakBarkItem;
import net.mcreator.survivalreborn.item.LargeMangroveBarkItem;
import net.mcreator.survivalreborn.item.LargeJungleBarkItem;
import net.mcreator.survivalreborn.item.LargeDarkOakBarkItem;
import net.mcreator.survivalreborn.item.LargeCrimsonBarkItem;
import net.mcreator.survivalreborn.item.LargeCherryBarkItem;
import net.mcreator.survivalreborn.item.LargeBirchBarkItem;
import net.mcreator.survivalreborn.item.LargeAcaciaBarkItem;
import net.mcreator.survivalreborn.item.JunglePlankItem;
import net.mcreator.survivalreborn.item.JungleBarkItem;
import net.mcreator.survivalreborn.item.FlintToolItem;
import net.mcreator.survivalreborn.item.FiberousPlantSeedsItem;
import net.mcreator.survivalreborn.item.FiberousLeavesItem;
import net.mcreator.survivalreborn.item.DeepslateRockItem;
import net.mcreator.survivalreborn.item.DarkOakPlankItem;
import net.mcreator.survivalreborn.item.DarkOakBarkItem;
import net.mcreator.survivalreborn.item.CrimsonPlankItem;
import net.mcreator.survivalreborn.item.CrimsonBarkItem;
import net.mcreator.survivalreborn.item.CopperNuggetItem;
import net.mcreator.survivalreborn.item.CopperChunkItem;
import net.mcreator.survivalreborn.item.CopperChiselItem;
import net.mcreator.survivalreborn.item.CherryPlankItem;
import net.mcreator.survivalreborn.item.CherryBarkItem;
import net.mcreator.survivalreborn.item.BronzeIngotItem;
import net.mcreator.survivalreborn.item.BirchPlankItem;
import net.mcreator.survivalreborn.item.BirchBarkItem;
import net.mcreator.survivalreborn.item.AcaciaPlankItem;
import net.mcreator.survivalreborn.item.AcaciaBarkItem;
import net.mcreator.survivalreborn.SurvivalRebornMod;

public class SurvivalRebornModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(SurvivalRebornMod.MODID);
	public static final DeferredItem<Item> FLINTBLOCK = block(SurvivalRebornModBlocks.FLINTBLOCK);
	public static final DeferredItem<Item> FLINT_TOOL = REGISTRY.register("flint_tool", FlintToolItem::new);
	public static final DeferredItem<Item> OAK_BARK = REGISTRY.register("oak_bark", OakBarkItem::new);
	public static final DeferredItem<Item> DARK_OAK_BARK = REGISTRY.register("dark_oak_bark", DarkOakBarkItem::new);
	public static final DeferredItem<Item> SPRUCE_BARK = REGISTRY.register("spruce_bark", SpruceBarkItem::new);
	public static final DeferredItem<Item> BIRCH_BARK = REGISTRY.register("birch_bark", BirchBarkItem::new);
	public static final DeferredItem<Item> MANGROVE_BARK = REGISTRY.register("mangrove_bark", MangroveBarkItem::new);
	public static final DeferredItem<Item> CHERRY_BARK = REGISTRY.register("cherry_bark", CherryBarkItem::new);
	public static final DeferredItem<Item> ACACIA_BARK = REGISTRY.register("acacia_bark", AcaciaBarkItem::new);
	public static final DeferredItem<Item> JUNGLE_BARK = REGISTRY.register("jungle_bark", JungleBarkItem::new);
	public static final DeferredItem<Item> CRIMSON_BARK = REGISTRY.register("crimson_bark", CrimsonBarkItem::new);
	public static final DeferredItem<Item> WARPED_BARK = REGISTRY.register("warped_bark", WarpedBarkItem::new);
	public static final DeferredItem<Item> LARGE_OAK_BARK = REGISTRY.register("large_oak_bark", LargeOakBarkItem::new);
	public static final DeferredItem<Item> LARGE_DARK_OAK_BARK = REGISTRY.register("large_dark_oak_bark", LargeDarkOakBarkItem::new);
	public static final DeferredItem<Item> LARGE_SPRUCE_BARK = REGISTRY.register("large_spruce_bark", LargeSpruceBarkItem::new);
	public static final DeferredItem<Item> LARGE_BIRCH_BARK = REGISTRY.register("large_birch_bark", LargeBirchBarkItem::new);
	public static final DeferredItem<Item> LARGE_MANGROVE_BARK = REGISTRY.register("large_mangrove_bark", LargeMangroveBarkItem::new);
	public static final DeferredItem<Item> LARGE_CHERRY_BARK = REGISTRY.register("large_cherry_bark", LargeCherryBarkItem::new);
	public static final DeferredItem<Item> LARGE_ACACIA_BARK = REGISTRY.register("large_acacia_bark", LargeAcaciaBarkItem::new);
	public static final DeferredItem<Item> LARGE_JUNGLE_BARK = REGISTRY.register("large_jungle_bark", LargeJungleBarkItem::new);
	public static final DeferredItem<Item> LARGE_CRIMSON_BARK = REGISTRY.register("large_crimson_bark", LargeCrimsonBarkItem::new);
	public static final DeferredItem<Item> LARGE_WARPED_BARK = REGISTRY.register("large_warped_bark", LargeWarpedBarkItem::new);
	public static final DeferredItem<Item> STONE_ROCK = REGISTRY.register("stone_rock", StoneRockItem::new);
	public static final DeferredItem<Item> STONE_ROCK_BLOC = block(SurvivalRebornModBlocks.STONE_ROCK_BLOC);
	public static final DeferredItem<Item> PLANT_FIBER = REGISTRY.register("plant_fiber", PlantFiberItem::new);
	public static final DeferredItem<Item> COPPER_CHUNK = REGISTRY.register("copper_chunk", CopperChunkItem::new);
	public static final DeferredItem<Item> COPPER_NUGGET = REGISTRY.register("copper_nugget", CopperNuggetItem::new);
	public static final DeferredItem<Item> COPPER_CHISEL = REGISTRY.register("copper_chisel", CopperChiselItem::new);
	public static final DeferredItem<Item> SMALL_COAL_CHUNK = REGISTRY.register("small_coal_chunk", SmallCoalChunkItem::new);
	public static final DeferredItem<Item> TIN_ORE = block(SurvivalRebornModBlocks.TIN_ORE);
	public static final DeferredItem<Item> RAW_TIN = REGISTRY.register("raw_tin", RawTinItem::new);
	public static final DeferredItem<Item> TIN_INGOT = REGISTRY.register("tin_ingot", TinIngotItem::new);
	public static final DeferredItem<Item> TIN_NUGGET = REGISTRY.register("tin_nugget", TinNuggetItem::new);
	public static final DeferredItem<Item> DEEPSLATE_ROCK = REGISTRY.register("deepslate_rock", DeepslateRockItem::new);
	public static final DeferredItem<Item> DEEPSLATE_ROCK_BLOC = block(SurvivalRebornModBlocks.DEEPSLATE_ROCK_BLOC);
	public static final DeferredItem<Item> FIBEROUS_PLANT_STAGE_0 = block(SurvivalRebornModBlocks.FIBEROUS_PLANT_STAGE_0);
	public static final DeferredItem<Item> FIBEROUS_PLANT_STAGE_1 = block(SurvivalRebornModBlocks.FIBEROUS_PLANT_STAGE_1);
	public static final DeferredItem<Item> FIBEROUS_LEAVES = REGISTRY.register("fiberous_leaves", FiberousLeavesItem::new);
	public static final DeferredItem<Item> FIBEROUS_PLANT_SEEDS = REGISTRY.register("fiberous_plant_seeds", FiberousPlantSeedsItem::new);
	public static final DeferredItem<Item> FIBEROUS_PLANT_STAGE_2 = block(SurvivalRebornModBlocks.FIBEROUS_PLANT_STAGE_2);
	public static final DeferredItem<Item> FIBEROUS_PLANT_STAGE_3 = block(SurvivalRebornModBlocks.FIBEROUS_PLANT_STAGE_3);
	public static final DeferredItem<Item> FORGE = block(SurvivalRebornModBlocks.FORGE);
	public static final DeferredItem<Item> BRONZE_INGOT = REGISTRY.register("bronze_ingot", BronzeIngotItem::new);
	public static final DeferredItem<Item> ROUGH_BRONZE = REGISTRY.register("rough_bronze", RoughBronzeItem::new);
	public static final DeferredItem<Item> ROUGH_IRON = REGISTRY.register("rough_iron", RoughIronItem::new);
	public static final DeferredItem<Item> ROUGH_GOLD = REGISTRY.register("rough_gold", RoughGoldItem::new);
	public static final DeferredItem<Item> ROUGH_COPPER = REGISTRY.register("rough_copper", RoughCopperItem::new);
	public static final DeferredItem<Item> ROUGH_TIN = REGISTRY.register("rough_tin", RoughTinItem::new);
	public static final DeferredItem<Item> STONE_HAMMER = REGISTRY.register("stone_hammer", StoneHammerItem::new);
	public static final DeferredItem<Item> METAL_REFINING_TABLE = block(SurvivalRebornModBlocks.METAL_REFINING_TABLE);
	public static final DeferredItem<Item> OAK_PLANK = REGISTRY.register("oak_plank", OakPlankItem::new);
	public static final DeferredItem<Item> DARK_OAK_PLANK = REGISTRY.register("dark_oak_plank", DarkOakPlankItem::new);
	public static final DeferredItem<Item> SPRUCE_PLANK = REGISTRY.register("spruce_plank", SprucePlankItem::new);
	public static final DeferredItem<Item> BIRCH_PLANK = REGISTRY.register("birch_plank", BirchPlankItem::new);
	public static final DeferredItem<Item> ACACIA_PLANK = REGISTRY.register("acacia_plank", AcaciaPlankItem::new);
	public static final DeferredItem<Item> JUNGLE_PLANK = REGISTRY.register("jungle_plank", JunglePlankItem::new);
	public static final DeferredItem<Item> CHERRY_PLANK = REGISTRY.register("cherry_plank", CherryPlankItem::new);
	public static final DeferredItem<Item> MANGROVE_PLANK = REGISTRY.register("mangrove_plank", MangrovePlankItem::new);
	public static final DeferredItem<Item> CRIMSON_PLANK = REGISTRY.register("crimson_plank", CrimsonPlankItem::new);
	public static final DeferredItem<Item> WARPED_PLANK = REGISTRY.register("warped_plank", WarpedPlankItem::new);
	public static final DeferredItem<Item> STONE_SAW = REGISTRY.register("stone_saw", StoneSawItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
