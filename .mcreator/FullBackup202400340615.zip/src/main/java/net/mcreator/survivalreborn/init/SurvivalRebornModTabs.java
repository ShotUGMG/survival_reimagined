
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.survivalreborn.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.survivalreborn.SurvivalRebornMod;

public class SurvivalRebornModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, SurvivalRebornMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> SURVIVAL_REBORN = REGISTRY.register("survival_reborn",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.survival_reborn.survival_reborn")).icon(() -> new ItemStack(Items.FLINT)).displayItems((parameters, tabData) -> {
				tabData.accept(SurvivalRebornModItems.FLINT_TOOL.get());
				tabData.accept(SurvivalRebornModItems.OAK_BARK.get());
				tabData.accept(SurvivalRebornModItems.DARK_OAK_BARK.get());
				tabData.accept(SurvivalRebornModItems.SPRUCE_BARK.get());
				tabData.accept(SurvivalRebornModItems.BIRCH_BARK.get());
				tabData.accept(SurvivalRebornModItems.MANGROVE_BARK.get());
				tabData.accept(SurvivalRebornModItems.CHERRY_BARK.get());
				tabData.accept(SurvivalRebornModItems.ACACIA_BARK.get());
				tabData.accept(SurvivalRebornModItems.JUNGLE_BARK.get());
				tabData.accept(SurvivalRebornModItems.CRIMSON_BARK.get());
				tabData.accept(SurvivalRebornModItems.WARPED_BARK.get());
				tabData.accept(SurvivalRebornModItems.LARGE_OAK_BARK.get());
				tabData.accept(SurvivalRebornModItems.LARGE_DARK_OAK_BARK.get());
				tabData.accept(SurvivalRebornModItems.LARGE_SPRUCE_BARK.get());
				tabData.accept(SurvivalRebornModItems.LARGE_BIRCH_BARK.get());
				tabData.accept(SurvivalRebornModItems.LARGE_MANGROVE_BARK.get());
				tabData.accept(SurvivalRebornModItems.LARGE_CHERRY_BARK.get());
				tabData.accept(SurvivalRebornModItems.LARGE_ACACIA_BARK.get());
				tabData.accept(SurvivalRebornModItems.LARGE_JUNGLE_BARK.get());
				tabData.accept(SurvivalRebornModItems.LARGE_CRIMSON_BARK.get());
				tabData.accept(SurvivalRebornModItems.LARGE_WARPED_BARK.get());
				tabData.accept(SurvivalRebornModItems.STONE_ROCK.get());
				tabData.accept(SurvivalRebornModItems.PLANT_FIBER.get());
				tabData.accept(SurvivalRebornModItems.COPPER_CHUNK.get());
				tabData.accept(SurvivalRebornModItems.COPPER_NUGGET.get());
				tabData.accept(SurvivalRebornModItems.COPPER_CHISEL.get());
				tabData.accept(SurvivalRebornModItems.SMALL_COAL_CHUNK.get());
				tabData.accept(SurvivalRebornModBlocks.TIN_ORE.get().asItem());
				tabData.accept(SurvivalRebornModItems.RAW_TIN.get());
				tabData.accept(SurvivalRebornModItems.TIN_INGOT.get());
				tabData.accept(SurvivalRebornModItems.TIN_NUGGET.get());
				tabData.accept(SurvivalRebornModItems.DEEPSLATE_ROCK.get());
				tabData.accept(SurvivalRebornModItems.FIBEROUS_LEAVES.get());
				tabData.accept(SurvivalRebornModItems.FIBEROUS_PLANT_SEEDS.get());
				tabData.accept(SurvivalRebornModBlocks.FORGE.get().asItem());
				tabData.accept(SurvivalRebornModItems.BRONZE_INGOT.get());
				tabData.accept(SurvivalRebornModItems.ROUGH_BRONZE.get());
				tabData.accept(SurvivalRebornModItems.ROUGH_IRON.get());
				tabData.accept(SurvivalRebornModItems.ROUGH_GOLD.get());
				tabData.accept(SurvivalRebornModItems.ROUGH_COPPER.get());
				tabData.accept(SurvivalRebornModItems.ROUGH_TIN.get());
				tabData.accept(SurvivalRebornModItems.STONE_HAMMER.get());
				tabData.accept(SurvivalRebornModBlocks.METAL_REFINING_TABLE.get().asItem());
				tabData.accept(SurvivalRebornModItems.OAK_PLANK.get());
				tabData.accept(SurvivalRebornModItems.DARK_OAK_PLANK.get());
				tabData.accept(SurvivalRebornModItems.SPRUCE_PLANK.get());
				tabData.accept(SurvivalRebornModItems.BIRCH_PLANK.get());
				tabData.accept(SurvivalRebornModItems.ACACIA_PLANK.get());
				tabData.accept(SurvivalRebornModItems.JUNGLE_PLANK.get());
				tabData.accept(SurvivalRebornModItems.CHERRY_PLANK.get());
				tabData.accept(SurvivalRebornModItems.MANGROVE_PLANK.get());
				tabData.accept(SurvivalRebornModItems.CRIMSON_PLANK.get());
				tabData.accept(SurvivalRebornModItems.WARPED_PLANK.get());
				tabData.accept(SurvivalRebornModItems.STONE_SAW.get());
			}).withSearchBar().build());
}
