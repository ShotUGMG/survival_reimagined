
package net.mcreator.survivalreborn.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class LargeBirchBarkItem extends Item {
	public LargeBirchBarkItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
