
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.survivalreborn.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.mcreator.survivalreborn.SurvivalRebornMod;

public class SurvivalRebornModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, SurvivalRebornMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> BLOCK_CARVING_CRAFTING_TABLE = REGISTRY.register("block.carving_crafting_table",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("survival_reborn", "block.carving_crafting_table")));
	public static final DeferredHolder<SoundEvent, SoundEvent> BLOCK_CARVE_PROGRESS = REGISTRY.register("block.carve_progress",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("survival_reborn", "block.carve_progress")));
}
