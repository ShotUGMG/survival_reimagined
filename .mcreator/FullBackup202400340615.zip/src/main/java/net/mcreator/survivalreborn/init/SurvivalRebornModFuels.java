
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.survivalreborn.init;

import net.neoforged.neoforge.event.furnace.FurnaceFuelBurnTimeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;

@EventBusSubscriber
public class SurvivalRebornModFuels {
	@SubscribeEvent
	public static void furnaceFuelBurnTimeEvent(FurnaceFuelBurnTimeEvent event) {
		ItemStack itemstack = event.getItemStack();
		if (itemstack.getItem() == SurvivalRebornModItems.OAK_BARK.get())
			event.setBurnTime(200);
		else if (itemstack.getItem() == SurvivalRebornModItems.DARK_OAK_BARK.get())
			event.setBurnTime(200);
		else if (itemstack.getItem() == SurvivalRebornModItems.SPRUCE_BARK.get())
			event.setBurnTime(200);
		else if (itemstack.getItem() == SurvivalRebornModItems.BIRCH_BARK.get())
			event.setBurnTime(300);
		else if (itemstack.getItem() == SurvivalRebornModItems.MANGROVE_BARK.get())
			event.setBurnTime(300);
		else if (itemstack.getItem() == SurvivalRebornModItems.CHERRY_BARK.get())
			event.setBurnTime(300);
		else if (itemstack.getItem() == SurvivalRebornModItems.ACACIA_BARK.get())
			event.setBurnTime(200);
		else if (itemstack.getItem() == SurvivalRebornModItems.JUNGLE_BARK.get())
			event.setBurnTime(200);
		else if (itemstack.getItem() == SurvivalRebornModItems.LARGE_OAK_BARK.get())
			event.setBurnTime(400);
		else if (itemstack.getItem() == SurvivalRebornModItems.LARGE_DARK_OAK_BARK.get())
			event.setBurnTime(400);
		else if (itemstack.getItem() == SurvivalRebornModItems.LARGE_SPRUCE_BARK.get())
			event.setBurnTime(400);
		else if (itemstack.getItem() == SurvivalRebornModItems.LARGE_BIRCH_BARK.get())
			event.setBurnTime(600);
		else if (itemstack.getItem() == SurvivalRebornModItems.LARGE_MANGROVE_BARK.get())
			event.setBurnTime(600);
		else if (itemstack.getItem() == SurvivalRebornModItems.LARGE_CHERRY_BARK.get())
			event.setBurnTime(600);
		else if (itemstack.getItem() == SurvivalRebornModItems.LARGE_ACACIA_BARK.get())
			event.setBurnTime(400);
		else if (itemstack.getItem() == SurvivalRebornModItems.LARGE_JUNGLE_BARK.get())
			event.setBurnTime(400);
		else if (itemstack.getItem() == SurvivalRebornModItems.SMALL_COAL_CHUNK.get())
			event.setBurnTime(800);
		else if (itemstack.getItem() == SurvivalRebornModItems.FIBEROUS_LEAVES.get())
			event.setBurnTime(200);
	}
}
