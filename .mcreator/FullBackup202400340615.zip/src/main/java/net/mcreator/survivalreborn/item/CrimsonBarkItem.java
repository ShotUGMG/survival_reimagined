
package net.mcreator.survivalreborn.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class CrimsonBarkItem extends Item {
	public CrimsonBarkItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
