
package net.mcreator.survivalreborn.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class CherryPlankItem extends Item {
	public CherryPlankItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
