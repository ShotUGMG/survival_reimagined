
package net.mcreator.survivalreborn.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class LargeWarpedBarkItem extends Item {
	public LargeWarpedBarkItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
