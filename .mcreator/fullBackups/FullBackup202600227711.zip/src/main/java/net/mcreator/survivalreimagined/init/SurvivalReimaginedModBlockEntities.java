/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.survivalreimagined.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.items.wrapper.SidedInvWrapper;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.Block;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.survivalreimagined.block.entity.*;
import net.mcreator.survivalreimagined.SurvivalReimaginedMod;

@EventBusSubscriber
public class SurvivalReimaginedModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK_ENTITY_TYPE, SurvivalReimaginedMod.MODID);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ForgeBlockEntity>> FORGE = register("forge", SurvivalReimaginedModBlocks.FORGE, ForgeBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MetalRefiningTableBlockEntity>> METAL_REFINING_TABLE = register("metal_refining_table", SurvivalReimaginedModBlocks.METAL_REFINING_TABLE, MetalRefiningTableBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MineralProcessingTableBlockEntity>> MINERAL_PROCESSING_TABLE = register("mineral_processing_table", SurvivalReimaginedModBlocks.MINERAL_PROCESSING_TABLE,
			MineralProcessingTableBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AppleTreeSaplingBlockEntity>> APPLE_TREE_SAPLING = register("apple_tree_sapling", SurvivalReimaginedModBlocks.APPLE_TREE_SAPLING, AppleTreeSaplingBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AppleBlockEntity>> APPLE = register("apple", SurvivalReimaginedModBlocks.APPLE, AppleBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<HempBlockEntity>> HEMP = register("hemp", SurvivalReimaginedModBlocks.HEMP, HempBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AdvancedAlloyForgeBlockEntity>> ADVANCED_ALLOY_FORGE = register("advanced_alloy_forge", SurvivalReimaginedModBlocks.ADVANCED_ALLOY_FORGE, AdvancedAlloyForgeBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RuneMagicInfuserBlockEntity>> RUNE_MAGIC_INFUSER = register("rune_magic_infuser", SurvivalReimaginedModBlocks.RUNE_MAGIC_INFUSER, RuneMagicInfuserBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SmallTroughBlockEntity>> SMALL_TROUGH = register("small_trough", SurvivalReimaginedModBlocks.SMALL_TROUGH, SmallTroughBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PalmLeavesBlockEntity>> PALM_LEAVES = register("palm_leaves", SurvivalReimaginedModBlocks.PALM_LEAVES, PalmLeavesBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<StrawberryPlantBlockEntity>> STRAWBERRY_PLANT = register("strawberry_plant", SurvivalReimaginedModBlocks.STRAWBERRY_PLANT, StrawberryPlantBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<BananaLeavesBlockEntity>> BANANA_LEAVES = register("banana_leaves", SurvivalReimaginedModBlocks.BANANA_LEAVES, BananaLeavesBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<BananaBlockEntity>> BANANA_CLUSTER = register("banana_cluster", SurvivalReimaginedModBlocks.BANANA_CLUSTER, BananaBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<BananaGrowBlockBlockEntity>> BANANA_GROW_BLOCK = register("banana_grow_block", SurvivalReimaginedModBlocks.BANANA_GROW_BLOCK, BananaGrowBlockBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MandarinFruitBlockEntity>> MANDARIN_FRUIT = register("mandarin_fruit", SurvivalReimaginedModBlocks.MANDARIN_FRUIT, MandarinFruitBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MandarinSaplingBlockEntity>> MANDARIN_SAPLING = register("mandarin_sapling", SurvivalReimaginedModBlocks.MANDARIN_SAPLING, MandarinSaplingBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MillstoneBlockEntity>> MILLSTONE = register("millstone", SurvivalReimaginedModBlocks.MILLSTONE, MillstoneBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CampfireBlockEntity>> CAMPFIRE = register("campfire", SurvivalReimaginedModBlocks.CAMPFIRE, CampfireBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<LowFertilityFarmlandBlockEntity>> LOW_FERTILITY_FARMLAND = register("low_fertility_farmland", SurvivalReimaginedModBlocks.LOW_FERTILITY_FARMLAND,
			LowFertilityFarmlandBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MediumFertilitySoilBlockEntity>> MEDIUM_FERTILITY_SOIL = register("medium_fertility_soil", SurvivalReimaginedModBlocks.MEDIUM_FERTILITY_SOIL,
			MediumFertilitySoilBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<HighFertilitySoilBlockEntity>> HIGH_FERTILITY_SOIL = register("high_fertility_soil", SurvivalReimaginedModBlocks.HIGH_FERTILITY_SOIL, HighFertilitySoilBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<BeetrootBlockEntity>> BEETROOT = register("beetroot", SurvivalReimaginedModBlocks.BEETROOT, BeetrootBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<BlockOfCharcoalBlockEntity>> BLOCK_OF_CHARCOAL = register("block_of_charcoal", SurvivalReimaginedModBlocks.BLOCK_OF_CHARCOAL, BlockOfCharcoalBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CowCarcassBlockEntity>> COW_CARCASS = register("cow_carcass", SurvivalReimaginedModBlocks.COW_CARCASS, CowCarcassBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SheepCarcassBlockEntity>> SHEEP_CARCASS = register("sheep_carcass", SurvivalReimaginedModBlocks.SHEEP_CARCASS, SheepCarcassBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ChickenCarcassBlockEntity>> CHICKEN_CARCASS = register("chicken_carcass", SurvivalReimaginedModBlocks.CHICKEN_CARCASS, ChickenCarcassBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PigCarcassBlockEntity>> PIG_CARCASS = register("pig_carcass", SurvivalReimaginedModBlocks.PIG_CARCASS, PigCarcassBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GoatCarcassBlockEntity>> GOAT_CARCASS = register("goat_carcass", SurvivalReimaginedModBlocks.GOAT_CARCASS, GoatCarcassBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<DryingRackBlockEntity>> DRYING_RACK = register("drying_rack", SurvivalReimaginedModBlocks.DRYING_RACK, DryingRackBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<TanningBarrelBlockEntity>> TANNING_BARREL = register("tanning_barrel", SurvivalReimaginedModBlocks.TANNING_BARREL, TanningBarrelBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<WheatCropBlockEntity>> WHEAT_CROP = register("wheat_crop", SurvivalReimaginedModBlocks.WHEAT_CROP, WheatCropBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CornStalkBottomBlockEntity>> CORN_STALK_BOTTOM = register("corn_stalk_bottom", SurvivalReimaginedModBlocks.CORN_STALK_BOTTOM, CornStalkBottomBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CarrotsBlockEntity>> CARROTS = register("carrots", SurvivalReimaginedModBlocks.CARROTS, CarrotsBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PotatoesBlockEntity>> POTATOES = register("potatoes", SurvivalReimaginedModBlocks.POTATOES, PotatoesBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SpeltSeedsBlockEntity>> SPELT_SEEDS = register("spelt_seeds", SurvivalReimaginedModBlocks.SPELT_SEEDS, SpeltSeedsBlockEntity::new);

	// Start of user code block custom block entities
	// End of user code block custom block entities
	private static <T extends BlockEntity> DeferredHolder<BlockEntityType<?>, BlockEntityType<T>> register(String registryname, DeferredHolder<Block, Block> block, BlockEntityType.BlockEntitySupplier<T> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}

	@SubscribeEvent
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, CORN_STALK_BOTTOM.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, GOAT_CARCASS.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, MILLSTONE.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, MANDARIN_SAPLING.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, MANDARIN_FRUIT.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, MINERAL_PROCESSING_TABLE.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, WHEAT_CROP.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, BANANA_GROW_BLOCK.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, POTATOES.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, STRAWBERRY_PLANT.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, BLOCK_OF_CHARCOAL.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, DRYING_RACK.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ADVANCED_ALLOY_FORGE.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, APPLE.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, CHICKEN_CARCASS.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, METAL_REFINING_TABLE.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, PIG_CARCASS.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, HIGH_FERTILITY_SOIL.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, FORGE.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, APPLE_TREE_SAPLING.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, SHEEP_CARCASS.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, CARROTS.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, TANNING_BARREL.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, SPELT_SEEDS.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, HEMP.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, BANANA_CLUSTER.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, SMALL_TROUGH.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, RUNE_MAGIC_INFUSER.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, CAMPFIRE.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, PALM_LEAVES.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, BANANA_LEAVES.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, BEETROOT.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, LOW_FERTILITY_FARMLAND.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, MEDIUM_FERTILITY_SOIL.get(), SidedInvWrapper::new);
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, COW_CARCASS.get(), SidedInvWrapper::new);
	}
}