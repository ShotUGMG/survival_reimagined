package net.mcreator.survivalreimagined.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.util.RandomSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.mcreator.survivalreimagined.procedures.GrowingProcedureProcedure;

import com.google.common.collect.ImmutableMap;

public class CornStalkMiddleBlock extends Block {
	public static final IntegerProperty AGE_7 = BlockStateProperties.AGE_7;
	private final ImmutableMap<BlockState, VoxelShape> shapes = this.makeShapes();

	public CornStalkMiddleBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.CROP).instabreak().noCollission().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(AGE_7, 0));
	}

	private ImmutableMap<BlockState, VoxelShape> makeShapes() {
		return this.getShapeForEachState(state -> {
			if (state.getValue(AGE_7) == 1) {
				return box(0, 0, 0, 16, 13, 16);
			} else if (state.getValue(AGE_7) == 2) {
				return box(0, 0, 0, 16, 15.99, 16);
			} else if (state.getValue(AGE_7) == 3) {
				return box(0, 0, 0, 16, 15.99, 16);
			} else if (state.getValue(AGE_7) == 4) {
				return box(0, 0, 0, 16, 15.99, 16);
			} else if (state.getValue(AGE_7) == 5) {
				return box(0, 0, 0, 16, 15.99, 16);
			} else if (state.getValue(AGE_7) == 6) {
				return box(0, 0, 0, 16, 15.99, 16);
			} else if (state.getValue(AGE_7) == 7) {
				return box(0, 0, 0, 16, 15.99, 16);
			}
			return box(0, 0, 0, 16, 9, 16);
		});
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return shapes.get(state);
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(AGE_7);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		BlockState state = super.getStateForPlacement(context);
		if (state == null)
			return null;
		return state.setValue(AGE_7, 0);
	}

	@Override
	public void tick(BlockState blockstate, ServerLevel world, BlockPos pos, RandomSource random) {
		super.tick(blockstate, world, pos, random);
		GrowingProcedureProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ(), blockstate);
	}
}